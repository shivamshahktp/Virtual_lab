const express = require('express');
const router = express.Router();
const Room = require('../models/Room');

// POST /api/rooms - Create a new room with a random 6-character code
router.post('/', async (req, res) => {
  try {
    // Generate a random 6-character alphanumeric code (e.g., "X7B9QA")
    const newRoomId = Math.random().toString(36).substring(2, 8).toUpperCase();
    
    const room = new Room({ roomId: newRoomId });
    await room.save();
    
    res.status(201).json(room);
  } catch (error) {
    console.error('Error creating room:', error);
    res.status(500).json({ error: 'Failed to create room' });
  }
});

// GET /api/rooms/:roomId - Fetch an existing room's physics data
router.get('/:roomId', async (req, res) => {
  try {
    const room = await Room.findOne({ roomId: req.params.roomId });
    
    if (!room) {
      return res.status(404).json({ error: 'Room not found' });
    }
    
    res.status(200).json(room);
  } catch (error) {
    console.error('Error fetching room:', error);
    res.status(500).json({ error: 'Failed to fetch room' });
  }
});

module.exports = router;